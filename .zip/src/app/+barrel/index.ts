export { BarrelModule } from './barrel.module';
