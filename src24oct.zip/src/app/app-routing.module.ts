import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserAdminComponent } from './complex-components/user-admin/user-admin.component';
import { Layout } from './full-layout/full.layout.component';
import {Login} from './components/app-login/app.login.component';
export const routes: Routes = [
   {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  {
    path: '',
    component: Login,
    data: {
      title: 'Login'
    }
  },
  {
    path: 'Home',
    component: Layout,
    data: {
      title: 'Home'
    },
    children: [
      {
    path: 'userAdmin',
    component: UserAdminComponent,
    data: {
      title: 'User Admin'
    }
  }]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
