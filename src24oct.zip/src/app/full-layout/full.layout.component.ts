import { Component } from '@angular/core';

@Component({
  selector: 'app-layout',
  templateUrl: './full.layout.component.html'
})
export class Layout {
  title = 'app works!';
}
