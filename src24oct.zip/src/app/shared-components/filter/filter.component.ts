import { Component, OnInit, Input, Output,EventEmitter ,ViewChild } from '@angular/core';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit {
  @Output () public Filter;
  @ViewChild("multiselect") public multiselect: any;
 public Organisation: Array<string> = ['Organisation1', 'Organisation2', 'Organisation3',
 'Organisation4'];
 public Fleet: Array<string> = ['Fleet1', 'Fleet2', 'Fleet3'];
 public Asset: Array<string> = ['Asset1', 'Asset2', 'Asset3',
 'Asset4', 'Asset5', 'Asset6'];
    public organisation: any ;
    public fleet: any ;
    public asset: any;
  constructor() {
    this.Filter = new EventEmitter();
   }
  emitFilterCriteria(){
    this.Filter.emit([this.organisation,this.fleet,this.asset]);
 }
addEvent() {
            this.Filter.emit('addeventClicked');
        }
clear() {
    this.organisation=null;
    this.fleet = null;
    this.asset = null;
    this.Filter.emit([this.organisation,this.fleet,this.asset]);
  }  
  public onCloseOrganisation(event: any) {
        event.preventDefault();
        //Close the list if the component is no longer focused
        setTimeout(() => {
            if(!this.multiselect.wrapper.nativeElement.contains(document.activeElement)) {
                this.multiselect.toggle(false);
            }
        });
    }
      public onCloseFleet(event: any) {
        event.preventDefault();
        //Close the list if the component is no longer focused
        setTimeout(() => {
            if(!this.multiselect.wrapper.nativeElement.contains(document.activeElement)) {
                this.multiselect.toggle(false);
            }
        });
    }
      public onCloseAsset(event: any) {
        event.preventDefault();
        //Close the list if the component is no longer focused
        setTimeout(() => {
            if(!this.multiselect.wrapper.nativeElement.contains(document.activeElement)) {
                this.multiselect.toggle(false);
            }
        });
    }
      ngOnInit() {
  }

}
