import { Component, OnInit, Input, Output,EventEmitter ,ViewChild } from '@angular/core';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';

@Component({
  selector: 'app-listbox-filter',
  templateUrl: './listbox.component.html',
  styleUrls: ['./listbox.component.css']
})
export class ListBoxComponent implements OnInit {
    @Input () getTableData;
    @Input () getTableHeaders;
    @Output () SelectedResults;
    public  myselection = [];
    private selectedData = [];
    private gridData = [{
    "Id": "ALFKI",
    "CompanyName": "Alfreds Futterkiste",
    "ContactName": "Maria Anders",
    "ContactTitle": "Sales Representative",
    "City": "Berlin"
}, {
    "Id": "ANATR",
    "CompanyName": "Ana Trujillo Emparedados y helados",
    "ContactName": "Ana Trujillo",
    "ContactTitle": "Owner",
    "City": "México D.F."
}, {
    "Id": "ANTON",
    "CompanyName": "Antonio Moreno Taquería",
    "ContactName": "Antonio Moreno",
    "ContactTitle": "Owner",
    "City": "México D.F."
}, {
    "Id": "AROUT",
    "CompanyName": "Around the Horn",
    "ContactName": "Thomas Hardy",
    "ContactTitle": "Sales Representative",
    "City": "London"
}, {
    "Id": "BERGS",
    "CompanyName": "Berglunds snabbköp",
    "ContactName": "Christina Berglund",
    "ContactTitle": "Order Administrator",
    "City": "Luleå"
}, {
    "Id": "BLAUS",
    "CompanyName": "Blauer See Delikatessen",
    "ContactName": "Hanna Moos",
    "ContactTitle": "Sales Representative",
    "City": "Mannheim"
}, {
    "Id": "BLONP",
    "CompanyName": "Blondesddsl père et fils",
    "ContactName": "Frédérique Citeaux",
    "ContactTitle": "Marketing Manager",
    "City": "Strasbourg"
}, {
    "Id": "BOLID",
    "CompanyName": "Bólido Comidas preparadas",
    "ContactName": "Martín Sommer",
    "ContactTitle": "Owner",
    "City": "Madrid"
}, {
    "Id": "BONAP",
    "CompanyName": "Bon app",
    "ContactName": "Laurence Lebihan",
    "ContactTitle": "Owner",
    "City": "Marseille"
}, {
    "Id": "BOTTM",
    "CompanyName": "Bottom-Dollar Markets",
    "ContactName": "Elizabeth Lincoln",
    "ContactTitle": "Accounting Manager",
    "City": "Tsawassen"
}];
  constructor() {
   }
      ngOnInit() {
  }
      moveRight() {
        if(this.gridData[this.myselection[0]])
        console.log(this.myselection);
        this.selectedData.push(this.gridData[this.myselection[0]]);
this.gridData = this.gridData.filter(item => item !== this.gridData[this.myselection[0]]);
        // delete this.gridData[this.myselection[0]];
      }
      moveLeft() {
        if(this.selectedData[this.myselection[0]])
        console.log(this.myselection);
        this.gridData.push(this.selectedData[this.myselection[0]]);
this.selectedData = this.selectedData.filter(item => item !== this.selectedData[this.myselection[0]]);
        // delete this.gridData[this.myselection[0]];
      }
      
      getData(event) {
        console.log(event);
        this.myselection = event;

      }
}
