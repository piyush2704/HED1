import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './app.login.component.html'
})
export class Login {
    constructor(private _route:Router) {

    }
  title = 'app works!';
  login () {
    this._route.navigate(['/Home/userAdmin'])
  }
}
